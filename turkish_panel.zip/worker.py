from __future__ import annotations

import asyncio
import logging
import random
import re
from dataclasses import dataclass
from typing import Any, Final

from playwright.async_api import (
    Browser,
    BrowserContext,
    Page,
    Playwright,
    TimeoutError as PlaywrightTimeoutError,
    async_playwright,
)
from playwright_stealth import Stealth

CookieDict = dict[str, Any]
CookieList = list[CookieDict]


@dataclass(slots=True)
class ProxyConfig:
    host: str
    port: int
    user: str | None = None
    password: str | None = None

    def to_playwright_proxy(self) -> dict[str, str]:
        proxy: dict[str, str] = {"server": f"http://{self.host}:{self.port}"}
        if self.user:
            proxy["username"] = self.user
        if self.password:
            proxy["password"] = self.password
        return proxy


@dataclass(slots=True)
class AccountSessionData:
    login: str
    password: str
    user_agent: str
    cookies: CookieList | None = None
    proxy: ProxyConfig | None = None


class AccountCaptchaError(RuntimeError):
    """Raised when Facebook blocks the session with a login wall/captcha."""


class FacebookBrowser:
    BASE_URL: Final[str] = "https://www.facebook.com/"
    DEFAULT_TIMEOUT_MS: Final[int] = 30_000
    LOGIN_TIMEOUT_MS: Final[int] = 60_000
    HUMAN_WAIT_MIN_MS: Final[int] = 2_000
    HUMAN_WAIT_MAX_MS: Final[int] = 5_000

    PATTERNS = {
        "LIKE": re.compile(r"Нравится|Like", re.IGNORECASE),
        "OPEN_COMMENT": re.compile(r"Оставить комментарий|Leave a comment|Комментарий|Comment", re.IGNORECASE),
        "INPUT_COMMENT": re.compile(r"Напишите комментарий|Write a comment|Комментарий|Comment", re.IGNORECASE),
        "REPLY": re.compile(r"Ответить|Reply", re.IGNORECASE),
        "INPUT_REPLY": re.compile(r"Ответить|Reply|Напишите ответ|Write a reply", re.IGNORECASE),
    }

    def __init__(self, account: AccountSessionData, headless: bool = True, strict_cookie_session: bool = True) -> None:
        self.account = account
        self.headless = headless
        self.strict_cookie_session = strict_cookie_session
        self.logger = logging.getLogger(self.__class__.__name__)

        self._playwright: Playwright | None = None
        self._browser: Browser | None = None
        self._context: BrowserContext | None = None
        self._page: Page | None = None

    async def __aenter__(self) -> FacebookBrowser:
        await self.start()
        return self

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
        await self.close()

    async def start(self) -> None:
        launch_options: dict[str, Any] = {"headless": self.headless}
        if self.account.proxy:
            launch_options["proxy"] = self.account.proxy.to_playwright_proxy()

        try:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(**launch_options)
            self._context = await self._browser.new_context(user_agent=self.account.user_agent, locale="en-US")
            self._page = await self._context.new_page()
            self._page.set_default_timeout(self.DEFAULT_TIMEOUT_MS)

            stealth = Stealth()
            await stealth.apply_stealth_async(self._page)
        except Exception as exc:
            self.logger.exception("Не удалось инициализировать браузер Facebook.")
            await self.close()
            raise RuntimeError("Не удалось запустить FacebookBrowser.") from exc

    async def close(self) -> None:
        if self._context:
            try:
                await self._context.close()
            except Exception:
                self.logger.exception("Ошибка при закрытии браузерного контекста.")
            finally:
                self._context = None
                self._page = None

        if self._browser:
            try:
                await self._browser.close()
            except Exception:
                self.logger.exception("Ошибка при закрытии браузера Chromium.")
            finally:
                self._browser = None

        if self._playwright:
            try:
                await self._playwright.stop()
            except Exception:
                self.logger.exception("Ошибка при остановке Playwright.")
            finally:
                self._playwright = None

    async def load_session(self) -> bool:
        context = self._require_context()
        if not self.account.cookies:
            self.logger.info("Cookies в БД отсутствуют для аккаунта %s.", self.account.login)
            return False

        try:
            await context.add_cookies(self.account.cookies)
            self.logger.info("Cookies загружены в браузерный контекст.")
            return True
        except PlaywrightTimeoutError:
            self.logger.exception("Таймаут Playwright при загрузке cookies.")
            return False
        except Exception:
            self.logger.exception("Ошибка при загрузке cookies в контекст.")
            return False

    async def login(self) -> CookieList:
        context = self._require_context()
        page = self._require_page()

        if await self.load_session():
            if await self._is_authorized():
                cookies = await context.cookies()
                self.account.cookies = cookies
                self.logger.info("Сессия через cookies валидна.")
                return cookies

            self.logger.warning("Cookies невалидны.")
            if self.strict_cookie_session:
                raise AccountCaptchaError("Cookie session is invalid and requires login/password.")
            await context.clear_cookies()
            self.logger.warning("Выполняется вход через форму.")
        elif self.strict_cookie_session:
            raise AccountCaptchaError("Cookie session is missing; login/password flow is disabled.")

        try:
            await page.goto(self.BASE_URL, wait_until="domcontentloaded", timeout=self.LOGIN_TIMEOUT_MS)
            await page.wait_for_selector('input[name="email"]', timeout=self.DEFAULT_TIMEOUT_MS)

            await self._type_human_like('input[name="email"]', self.account.login)
            await self._type_human_like('input[name="pass"]', self.account.password)
            await asyncio.sleep(random.uniform(0.8, 1.6))
            login_button = page.locator('button[name="login"]')
            clicked = await self._safe_click(login_button, "кнопке входа")
            if not clicked:
                self.logger.info("Не удалось кликнуть по кнопке входа, пробуем клавишу Enter.")
                await page.keyboard.press("Enter")
            else:
                self.logger.info("Нажали вход, ждем завершения возможной проверки.")
                await page.wait_for_timeout(15_000)

            await page.wait_for_load_state("domcontentloaded", timeout=self.LOGIN_TIMEOUT_MS)
            current_url = page.url.lower()
            if "checkpoint" in current_url:
                raise AccountCaptchaError("Facebook returned checkpoint after login attempt.")

            login_visible = await page.locator('input[name="email"]').is_visible(timeout=5_000)
            if login_visible:
                raise AccountCaptchaError("Login form is still visible after login attempt.")

            cookies = await context.cookies()
            self.account.cookies = cookies
            self.logger.info("Вход выполнен успешно, cookies обновлены.")
            return cookies
        except PlaywrightTimeoutError as exc:
            self.logger.exception("Таймаут Playwright во время авторизации.")
            raise RuntimeError("Таймаут при попытке входа в Facebook.") from exc

    async def _find_and_click(self, page: Page, pattern_key: str, element_name: str) -> bool:
        pattern = self.PATTERNS[pattern_key]
        locators = [
            page.get_by_role("button", name=pattern),
            page.get_by_label(pattern),
        ]
        for locator in locators:
            if await self._safe_click(locator, element_name):
                return True
        return False

    async def like_post(self, target_url: str) -> bool:
        page = self._require_page()
        try:
            await page.goto(target_url, wait_until="domcontentloaded", timeout=self.DEFAULT_TIMEOUT_MS)
        except Exception:
            self.logger.exception("Ошибка при открытии ссылки для лайка: %s", target_url)
            return False

        if await self._find_and_click(page, "LIKE", "кнопке лайка"):
            self.logger.info("Лайк успешно поставлен для ссылки: %s", target_url)
            return True

        self.logger.info("Кнопка лайка не найдена, возможно пост уже лайкнут: %s", target_url)
        return True

    async def leave_comment(self, target_url: str, text: str) -> bool:
        page = self._require_page()
        try:
            await page.goto(target_url, wait_until="domcontentloaded", timeout=self.DEFAULT_TIMEOUT_MS)
        except Exception:
            self.logger.exception("Ошибка при открытии ссылки для комментария: %s", target_url)
            return False

        if not await self._find_and_click(page, "OPEN_COMMENT", "кнопке открытия комментария"):
            self.logger.error("Не удалось открыть поле комментария для ссылки: %s", target_url)
            return False

        input_pattern = self.PATTERNS["INPUT_COMMENT"]
        input_locators = [
            page.get_by_role("textbox", name=input_pattern),
            page.get_by_label(input_pattern),
        ]

        comment_input = None
        for locator in input_locators:
            if await self._safe_click(locator, "полю ввода комментария"):
                comment_input = locator.first
                break

        if comment_input is None:
            self.logger.error("Поле ввода комментария не найдено для ссылки: %s", target_url)
            return False

        try:
            for symbol in text:
                await self._human_wait()
                await comment_input.type(symbol, delay=random.randint(80, 180))
            await self._human_wait()
            await page.keyboard.press("Enter")
            self.logger.info("Комментарий отправлен через Enter для ссылки: %s", target_url)
            await page.wait_for_timeout(2_000)
            return True
        except Exception:
            self.logger.exception("Критическая ошибка при вводе/отправке комментария.")
            return False

    async def like_comment(self, target_url: str) -> bool:
        page = self._require_page()
        try:
            await page.goto(target_url, wait_until="domcontentloaded", timeout=self.DEFAULT_TIMEOUT_MS)
        except Exception:
            self.logger.exception("Ошибка при открытии ссылки для лайка комментария: %s", target_url)
            return False

        if await self._find_and_click(page, "LIKE", "кнопке лайка комментария"):
            self.logger.info("Лайк комментария успешно поставлен для ссылки: %s", target_url)
            return True

        self.logger.error("Кнопка лайка комментария не найдена для ссылки: %s", target_url)
        return False

    async def reply_comment(self, target_url: str, text: str) -> bool:
        page = self._require_page()
        try:
            await page.goto(target_url, wait_until="domcontentloaded", timeout=self.DEFAULT_TIMEOUT_MS)
        except Exception:
            self.logger.exception("Ошибка при открытии ссылки для ответа на комментарий: %s", target_url)
            return False

        if not await self._find_and_click(page, "REPLY", "кнопке ответа на комментарий"):
            self.logger.error("Не удалось открыть поле ответа для ссылки: %s", target_url)
            return False

        input_pattern = self.PATTERNS["INPUT_REPLY"]
        input_locators = [
            page.get_by_role("textbox", name=input_pattern),
            page.get_by_label(input_pattern),
        ]

        reply_input = None
        for locator in input_locators:
            if await self._safe_click(locator, "полю ввода ответа"):
                reply_input = locator.first
                break

        if reply_input is None:
            self.logger.error("Поле ввода ответа не найдено для ссылки: %s", target_url)
            return False

        try:
            for symbol in text:
                await self._human_wait()
                await reply_input.type(symbol, delay=random.randint(80, 180))
            await self._human_wait()
            await page.keyboard.press("Enter")
            self.logger.info("Ответ на комментарий отправлен через Enter для ссылки: %s", target_url)
            await page.wait_for_timeout(2_000)
            return True
        except Exception:
            self.logger.exception("Критическая ошибка при вводе/отправке ответа.")
            return False

    async def _is_authorized(self) -> bool:
        page = self._require_page()
        context = self._require_context()
        try:
            await page.goto(self.BASE_URL, wait_until="domcontentloaded", timeout=self.DEFAULT_TIMEOUT_MS)
            cookies = await context.cookies()
            has_c_user = any(cookie.get("name") == "c_user" for cookie in cookies)
            login_form_count = await page.locator('form[action*="login"]').count()
            dialog_count = await page.locator('div[role="dialog"]').count()
            if not has_c_user:
                self.logger.warning("Не найден cookie c_user: сессия не авторизована.")
                if login_form_count > 0 or dialog_count > 0:
                    raise AccountCaptchaError("Login wall or captcha detected.")
                return False

            if "checkpoint" in page.url.lower():
                self.logger.warning("Обнаружен checkpoint при проверке сессии.")
                raise AccountCaptchaError("Checkpoint detected.")
            return True
        except PlaywrightTimeoutError:
            self.logger.exception("Таймаут при проверке валидности текущей сессии.")
            return False
        except AccountCaptchaError:
            raise
        except Exception:
            self.logger.exception("Ошибка при проверке валидности текущей сессии.")
            return False

    async def _type_human_like(self, selector: str, text: str) -> None:
        page = self._require_page()
        await page.click(selector)
        await page.fill(selector, "")

        for symbol in text:
            await page.type(selector, symbol, delay=random.randint(65, 170))
            if random.random() < 0.1:
                await asyncio.sleep(random.uniform(0.15, 0.45))

        await asyncio.sleep(random.uniform(0.2, 0.6))

    def _require_context(self) -> BrowserContext:
        if not self._context:
            raise RuntimeError("Браузерный контекст не инициализирован. Вызовите start().")
        return self._context

    async def _human_wait(self) -> None:
        page = self._require_page()
        await page.wait_for_timeout(random.uniform(self.HUMAN_WAIT_MIN_MS, self.HUMAN_WAIT_MAX_MS))

    async def _safe_click(self, locator: Any, element_name: str) -> bool:
        try:
            await self._human_wait()
            await locator.first.click(timeout=self.DEFAULT_TIMEOUT_MS)
            return True
        except PlaywrightTimeoutError:
            self.logger.info("Таймаут при клике по элементу: %s", element_name)
            return False
        except Exception:
            self.logger.info("Не удалось кликнуть по элементу: %s", element_name)
            return False

    def _require_page(self) -> Page:
        if not self._page:
            raise RuntimeError("Страница браузера не инициализирована. Вызовите start().")
        return self._page
